document.write("03_templates.js is linked")

//1.  Declare a variable firstName using let, and assign it a value that is your first name as a string

let firstName = 'Jonah'

//2.  Declare a variable lastName using let, and assign it a value that is your last name as a string

let lastName = 'Durbin'

//3.  Use a console log statement and template literals to create a greeting that logs "Hello, firstName lastName" to the console.  For example, "Hello, Jane Smith!"

console.log(`Hello ${firstName} ${lastName}`)