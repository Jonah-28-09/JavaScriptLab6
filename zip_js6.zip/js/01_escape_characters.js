document.write("01_escape_characters.js is linked")

//1.  Use a console log statement with an escape character to print the message 'Don't run away' to the console

console.log('Don\'t run away')

//2.  Use a console log statement with an escape character to print the message 'This \ is a backslash'

console.log('This \\ is a backslash')

//3.  Use a console log statement with the escape character \n in the phrase 'This \n is a new line' to demonstrate the use of the new line escape character \n

console.log("This \nis a new line")

//4.  Use a console log statement with the escape character \t in the phrase 'This \t is a horizontal tab' to demonstrate the use of the horizontal tab escape character \t

console.log('This \t is a horizontal tab')