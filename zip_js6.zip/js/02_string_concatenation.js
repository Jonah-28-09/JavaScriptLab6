document.write("02_string_concatenation.js is linked");
//1. Type your first name and last name into the variables below between the quotation marks
let firstName = "Jonah";
let lastName = "Durbin";

//2.  Use a console log statement to print out a greeting to the console that says "Hello,"" followed by your first name and last name.  i.e. Hello Jane Smith.  Make sure you add a space between the firstName and lastName

 console.log('Hello, ' + firstName + ' ' + lastName)